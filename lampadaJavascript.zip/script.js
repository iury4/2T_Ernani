const btnAlternar = document.getElementById('btn-Alternar')
const imgLampada = document.getElementById('lampada')
const baseUrl = "https://5fe84acf-4722-4eb7-927f-510de8ecda17-00-eqtqst72zovf.spock.replit.dev/"

btnAlternar.addEventListener('click', function() {

  if (imgLampada.src == baseUrl + 'lampada0.png') {
    imgLampada.src = "lampada2.png"
  } else {
    imgLampada.src = "lampada0.png"
  }
   


})
