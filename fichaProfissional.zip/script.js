const nome = document.getElementById('nome');

const novoNome = "sofia"

nome.innerHTML = novoNome

const sobreNome = document.getElementById('sobreNome');

const iagogay = "espanha"

sobreNome.innerHTML = iagogay

const idade = document.getElementById('idade');

const novaIdade = "66"

idade.innerHTML = novaIdade

const cgm = document.getElementById('cgm');

const novacgm = "1029379108"

cgm.innerHTML = novacgm

const email = document.getElementById('email');

const novaemail = "iagoreidelas@gmail.com"

email.innerHTML = novaemail