//selecionar com queryselector()
const vermelho = document.querySelector('.vermelho')
const verde = document.querySelector('.verde')
const azul = document.querySelector('.azul')
const amarelo = document.querySelector('.amarelo')
const branco = document.querySelector('.branco')
const conteudo = document.querySelector('.conteudo')
const bigtext = document.querySelector('.bigtext')

//alert(vermelho)
vermelho.addEventListener('click', function() {
  conteudo.style.backgroundColor = 'red'
  bigtext.style.color = 'black'
})
verde.addEventListener('click', function() {
  conteudo.style.backgroundColor = 'green'
  bigtext.style.color = 'black'
})
azul.addEventListener('click', function() {
  conteudo.style.backgroundColor = 'blue'
  bigtext.style.color = 'black'
})
amarelo.addEventListener('click', function() {
  conteudo.style.backgroundColor = 'yellow'
  bigtext.style.color = 'black'
})
branco.addEventListener('click', function() {
  conteudo.style.backgroundColor = 'white'
  bigtext.style.color = 'black'
})
