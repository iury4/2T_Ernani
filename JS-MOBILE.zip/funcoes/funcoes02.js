// function soma(n1, n2) {
//   if (typeof n1 === 'number' && typeof n2 === 'number') {
//     const res = n1 + n2;
//     alert('0 resultado foi:' + res)
//   } else {
//     alert('insira um numero valido')
//   }

// }



// // function verificarNomeAltura(nome, altura) {
// //   if (typeof nome === 'string' && typeof altura === 'number') {
// //     alert("OLÁ " + nome + ", sua altura é: " + altura);
// //   } else {
// //     alert("Por favor, insira um nome válido e uma altura numérica.");
// //   }
// //}

// // Exemplo de uso:
// verificarNomeAltura("Carlos", 1.81);
// verificarNomeAltura("iago", "gay");
// verificarNomeAltura("Carlos", true);
// // soma("hulk",5)
// //  soma(-5,5)
// //  soma("15",25)





