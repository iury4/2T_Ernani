

// function ola(nome, sobrenome) {
//   if (typeof nome === 'string' && typeof sobrenome === 'string') {
//     alert("OLÁ " + nome + " " + sobrenome);
//   } else {
//     alert("Por favor, insira um nome válido e uma altura numérica.");
//   }
// }

// ola("Carlos", "eduardo");

// function ola(N) {
//   if( typeof N ===  'number'){
//   if ( N % 2 === 0 ) {
//     alert("O número  " + N + " é par.");
//   } else {
//     alert("0 NUMERO " + N + " é impar")
//   }
//     }
//   else{
//   alert("por favor insira um valor valido")
    
//   }}



// ola(2)
// ola(1)
// ola('s')