// const nome = 'laura'
// function retornaDados(){
//   //codigo com retorno 
//   return nome.toUpperCase()
// }
// const dados = retornaDados()
// console.log (dados)


const nome = 'carlos'
const idade = '99'
const cpf = '123456789'

function armazenadorDAdos() {
  return (nome + idade + cpf)



}

dados = armazenadorDAdos
console.log(dados);


