/**
 *FUNCÕES:são blocos de código que podem ser reaproveitados
 * funcões podem ou não ter nomes
 * podem ou não ter parâmetros
 */
//criar ou declarar funcões 

function diz0la(nome) {
  //codigo que sera excutado 
  console.log('olá ' + nome)


}
diz0la('carlinhos')
diz0la('chalin matador de porco')
diz0la('bolsonaro')

//invocar / chamar funções 

//função para 

//audição
function somaDoisNumeros(x, y) {
  const soma = x + y
  console.log(soma)
}
somaDoisNumeros(5, 9)
somaDoisNumeros(1, 5)

//subtração 
function subtracaoDoisNumeros(x, y) {
  const subtracao = x - y
  console.log(subtracao)
}
subtracaoDoisNumeros(5000000000000, 9)
subtracaoDoisNumeros(1000000, 5)

//divisão 
function divisaoDoisNumeros(x, y) {
  const divisao = x / y
  console.log(divisao)
}
divisaoDoisNumeros(5000000000000, 9)
divisaoDoisNumeros(1000000, 5)

//multiplicar
function multiplicarDoisNumeros(x, y) {
  const multiplicar = x.y
  console.log(multiplicar)
}
multiplicarDoisNumeros(800000, 10)
multiplicarDoisNumeros(900, 50)