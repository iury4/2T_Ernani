/**
* DECLARAÇÃO DE VARIÁVEIS JAVACRIPT
* indetificador: nome da variável
  valor: valor da variável
*/
const nome = "cat"; // escopo global - mutável
const sobrenome = "Mi-amor"; //escopo em bloco - mutável
const idade = 2;//escopo em bloco - imutável

//retribuir valore
//pet = "mi-amor"; 
//nome = "CARLOS";
// pi = 3.14 vai da erro(porque é consta)

const dadosPessoais = nome + " " + sobrenome + " " + idade
const ano = 2024
const anoNascimeto = 2007
const idadeAtual = ano - anoNascimeto
const num = 24
const ehpar = num % 2 == 0 // parole
const ehimpar = num % 2 == 1 // impar

//if = se - else - senãoimparOu
if (ehpar) {
  console.log("o números é par")
} else {
  console.log("o número é impar")
}

//console.log(parOuimpar)
//console.log(imparOupar)

//console.log(idadeAtual + " anos")
//console.log(dadosPessoais)

//console.log = saida de teste 
/*crie uma variavel para cada situação */



const passatempo = "jogar"
const cidade = "curitiba"
const precoDolar = "5-12"
const animalEstimacao = "mi-amor"
const estadoSolteiro = "true"





//console.log(" passa tempo " + passatempo + " cidade " + cidade + " preço do dolar  " + precoDolar + " animal de estimação " + animalEstimacao + " estado " + estadoSolteiro)

